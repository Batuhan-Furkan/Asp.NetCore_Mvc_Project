﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;

namespace HastaneRandevuSistemi.Models
{
    public class KullaniciModel
    {
        [Key]
        public int KullaniciId { get; set; }
        [Required]
        [MaxLength(50)]
        public string Ad { get; set; }
        [Required]
        [MaxLength(50)]
        public string Soyad { get; set; }
        [Required]
        [StringLength(11,MinimumLength =11)]
        
        public string TcNo { get; set; }
        [Required]
        [Display(Name = "Dogum Tarihi")]
        [DisplayFormat(DataFormatString = "{0:dd-MMM-yyy}",ApplyFormatInEditMode =true)]
        public DateTime DogumTarihi { get; set; }
        [Required]
        [StringLength(10, MinimumLength = 10)]
        [RegularExpression(@"^\d{10}$", ErrorMessage = "Telefon numarası 10 haneli olmalıdır.")]
        
        public string Telefon { get; set; }
        [Required]
        [EmailAddress]
        public string Mail { get; set; }
        [Required]
        public bool Cinsiyet { get; set; }
        
        [Required]
        [PasswordPropertyText]
        public string Sifre { get; set; }
    }
}
