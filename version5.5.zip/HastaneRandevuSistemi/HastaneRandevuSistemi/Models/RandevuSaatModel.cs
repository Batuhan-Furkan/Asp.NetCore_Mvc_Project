﻿using System.ComponentModel.DataAnnotations;

namespace HastaneRandevuSistemi.Models
{
    public class RandevuSaatModel
    {
        [Key]
        public int id { get; set; }
        public bool musaitmi { get; set; } = true;
        public List<TimeSpan> Saat { get; set; }
        public DateTime Gun { get; set; }

    }
}
