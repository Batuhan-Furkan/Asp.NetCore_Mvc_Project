﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HastaneRandevuSistemi.Models
{
    public class RandevuModel
    {
        [Key]
        public int Id { get; set; }
        //[ForeignKey("KullaniciTcNo")]
        //public string KullaniciTcNo { get; set; }
        [ForeignKey("DoktorId")]
        public int DoktorId { get; set; }
        public bool Musait {  get; set; }
        [ForeignKey("Gun")]
        public DateTime Gun {  get; set; }
        public RandevuSaatModel RandevuSaatModel { get; set; }
        [ForeignKey("Saat")]
        public List<TimeSpan> Saat { get; set; }
    }
}
