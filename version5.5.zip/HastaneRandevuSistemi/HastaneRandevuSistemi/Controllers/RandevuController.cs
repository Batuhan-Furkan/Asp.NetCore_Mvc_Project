﻿using HastaneRandevuSistemi.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace HastaneRandevuSistemi.Controllers
{
    [Authorize(Roles ="Hasta")]
    public class RandevuController : Controller
    {

        private MyContext db = new MyContext();
        //private readonly RandevuServices _randevuService;
       
        public IActionResult RandevuAl()
        {
            // Bugünden itibaren müsait saatleri al
            var bugun = DateTime.Today;
            var musaitSaatler = GetMusaitsForDate(bugun);

            ViewBag.MusaitSaatler = musaitSaatler;

            return View();
        }
        [HttpPost]
        public IActionResult RandevuAl(DateTime tarih, List<TimeSpan> saat)
        {
            // Randevu al
            DbKaydet(tarih, saat);

            return RedirectToAction("Index", "Home");
        }
        
        public List<TimeSpan> GetMusaitsForDate(DateTime tarih)
        {
            var randevular = db.RandevuTablosu
                .Where(r => r.Gun == tarih)
                .ToList();


            List<TimeSpan> saatListesi = new List<TimeSpan>();
            TimeSpan baslangicSaat = TimeSpan.FromHours(9);

            while (baslangicSaat < TimeSpan.FromHours(18))
            {
                saatListesi.Add(baslangicSaat);
                baslangicSaat = baslangicSaat.Add(TimeSpan.FromMinutes(15));
            }

            // RandevuSaat nesnesini oluşturun ve Saatler özelliğine liste atayın
            RandevuSaatModel randevuSaat = new RandevuSaatModel
            {
                Saat = saatListesi
            };

            // RandevuSaat nesnesini veritabanına ekleyin
            using (var context = new MyContext())
            {
                //context.Database.EnsureCreated(); // Veritabanını oluştur
                context.randevuSaatTablosu.Add(randevuSaat);
                context.SaveChanges();
            }









            //var musaitSaatler = Enumerable.Range(9, 9) // 9:00'dan başlayarak 6:00'a kadar
            //    .SelectMany(saat => new List<TimeSpan>
            //    {
            //    TimeSpan.FromHours(saat),
            //    TimeSpan.FromHours(saat).Add(TimeSpan.FromMinutes(15)),
            //    TimeSpan.FromHours(saat).Add(TimeSpan.FromMinutes(30)),
            //    TimeSpan.FromHours(saat).Add(TimeSpan.FromMinutes(45))
            //    })
            //    .ToList();

            //foreach (var randevu in randevular)
            //{
            //    if (db.RandevuTablosu.Any(p => p.Gun == tarih && p.Musait == false))
            //    {
            //        musaitSaatler.Remove(randevu.Saat);
            //    }
            //}

            return saatListesi;
        }

        public void DbKaydet(DateTime tarih, List<TimeSpan> saat)
        {
            var randevu = new RandevuModel
            {
                Gun = tarih,
                Saat = saat,
                Musait = false,
                DoktorId = 5,
            };

            db.RandevuTablosu.Add(randevu);
            db.SaveChanges();
        }

    }

    
}
