﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace HastaneRandevuSistemi.Migrations
{
    public partial class _30 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "KullaniciTcNo",
                table: "RandevuTablosu");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "KullaniciTcNo",
                table: "RandevuTablosu",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }
    }
}
