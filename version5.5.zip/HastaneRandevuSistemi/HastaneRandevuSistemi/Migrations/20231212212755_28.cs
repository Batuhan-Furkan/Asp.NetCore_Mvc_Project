﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace HastaneRandevuSistemi.Migrations
{
    public partial class _28 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_RandevuTablosu_DoktorTablosu_DoktorId",
                table: "RandevuTablosu");

            migrationBuilder.DropIndex(
                name: "IX_RandevuTablosu_DoktorId",
                table: "RandevuTablosu");

            migrationBuilder.RenameColumn(
                name: "Tarih",
                table: "RandevuTablosu",
                newName: "Gun");

            migrationBuilder.RenameColumn(
                name: "RandevuId",
                table: "RandevuTablosu",
                newName: "Id");

            migrationBuilder.AddColumn<int>(
                name: "DoktorModelDoktorId",
                table: "RandevuTablosu",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "KullaniciTcNo",
                table: "RandevuTablosu",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<bool>(
                name: "Musait",
                table: "RandevuTablosu",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<TimeSpan>(
                name: "Saat",
                table: "RandevuTablosu",
                type: "time",
                nullable: false,
                defaultValue: new TimeSpan(0, 0, 0, 0, 0));

            migrationBuilder.CreateIndex(
                name: "IX_RandevuTablosu_DoktorModelDoktorId",
                table: "RandevuTablosu",
                column: "DoktorModelDoktorId");

            migrationBuilder.AddForeignKey(
                name: "FK_RandevuTablosu_DoktorTablosu_DoktorModelDoktorId",
                table: "RandevuTablosu",
                column: "DoktorModelDoktorId",
                principalTable: "DoktorTablosu",
                principalColumn: "DoktorId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_RandevuTablosu_DoktorTablosu_DoktorModelDoktorId",
                table: "RandevuTablosu");

            migrationBuilder.DropIndex(
                name: "IX_RandevuTablosu_DoktorModelDoktorId",
                table: "RandevuTablosu");

            migrationBuilder.DropColumn(
                name: "DoktorModelDoktorId",
                table: "RandevuTablosu");

            migrationBuilder.DropColumn(
                name: "KullaniciTcNo",
                table: "RandevuTablosu");

            migrationBuilder.DropColumn(
                name: "Musait",
                table: "RandevuTablosu");

            migrationBuilder.DropColumn(
                name: "Saat",
                table: "RandevuTablosu");

            migrationBuilder.RenameColumn(
                name: "Gun",
                table: "RandevuTablosu",
                newName: "Tarih");

            migrationBuilder.RenameColumn(
                name: "Id",
                table: "RandevuTablosu",
                newName: "RandevuId");

            migrationBuilder.CreateIndex(
                name: "IX_RandevuTablosu_DoktorId",
                table: "RandevuTablosu",
                column: "DoktorId");

            migrationBuilder.AddForeignKey(
                name: "FK_RandevuTablosu_DoktorTablosu_DoktorId",
                table: "RandevuTablosu",
                column: "DoktorId",
                principalTable: "DoktorTablosu",
                principalColumn: "DoktorId",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
