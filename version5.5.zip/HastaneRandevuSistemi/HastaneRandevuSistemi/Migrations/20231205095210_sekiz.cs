﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace HastaneRandevuSistemi.Migrations
{
    public partial class sekiz : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "Mail",
                table: "KullaniciTablosu",
                type: "nvarchar(450)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AddColumn<DateTime>(
                name: "DogumTarihi",
                table: "KullaniciTablosu",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<string>(
                name: "Telefon",
                table: "KullaniciTablosu",
                type: "nvarchar(10)",
                maxLength: 10,
                nullable: false,
                defaultValue: "");

            migrationBuilder.CreateIndex(
                name: "IX_KullaniciTablosu_Mail",
                table: "KullaniciTablosu",
                column: "Mail",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_KullaniciTablosu_TcNo",
                table: "KullaniciTablosu",
                column: "TcNo",
                unique: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_KullaniciTablosu_Mail",
                table: "KullaniciTablosu");

            migrationBuilder.DropIndex(
                name: "IX_KullaniciTablosu_TcNo",
                table: "KullaniciTablosu");

            migrationBuilder.DropColumn(
                name: "DogumTarihi",
                table: "KullaniciTablosu");

            migrationBuilder.DropColumn(
                name: "Telefon",
                table: "KullaniciTablosu");

            migrationBuilder.AlterColumn<string>(
                name: "Mail",
                table: "KullaniciTablosu",
                type: "nvarchar(max)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(450)");
        }
    }
}
