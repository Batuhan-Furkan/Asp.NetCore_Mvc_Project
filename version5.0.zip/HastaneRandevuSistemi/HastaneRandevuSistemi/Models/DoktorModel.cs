﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace HastaneRandevuSistemi.Models
{
    public class DoktorModel
    {
        [Key]
        public int DoktorId { get; set; }
        [Required]
        public string state { get; set; } = "Doktor";

        [Required]
        [MaxLength(50)]
        public string DoktorAdi { get; set; }
        [Required]
        [MaxLength(50)]
        public string DoktorSoyad { get; set; }
        [Required]
        [StringLength(11, MinimumLength = 11)]
        public string DoktorTcNo { get; set; }
        [Required]
        [StringLength(10, MinimumLength = 10)]
        [RegularExpression(@"^\d{10}$", ErrorMessage = "Telefon numarası 10 haneli olmalıdır.")]
        public string DoktorTelefon { get; set; }
        [Required]
        [EmailAddress]
        public string DoktorMail { get; set; }
        [Required]
        [DataType(DataType.Password)]
        public string DoktorSifre { get; set; }
        [Required]
        [DataType(DataType.Password)]
        [Compare("DoktorSifre")]
        [NotMapped]
        public string DoktorSifreTekrar { get; set; }


       // public ICollection<KullaniciModel> kullanici { get; set; }
    }
}
