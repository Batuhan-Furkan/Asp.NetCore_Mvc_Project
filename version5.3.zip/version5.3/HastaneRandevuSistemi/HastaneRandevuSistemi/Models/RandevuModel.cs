﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HastaneRandevuSistemi.Models
{
    public class RandevuModel
    {
        [Key]
        public int RandevuId { get; set; }
        public int DoktorId { get; set; }
        [ForeignKey("DoktorId")]
        public DoktorModel Doktor { get; set; }
        public DateTime Tarih { get; set; }
      
    }
}
