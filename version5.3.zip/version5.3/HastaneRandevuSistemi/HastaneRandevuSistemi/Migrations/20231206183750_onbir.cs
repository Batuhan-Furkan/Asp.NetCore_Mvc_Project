﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace HastaneRandevuSistemi.Migrations
{
    public partial class onbir : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_KullaniciTablosu_DoktorTablosu_DoktorId",
                table: "KullaniciTablosu");

            migrationBuilder.AlterColumn<int>(
                name: "DoktorId",
                table: "KullaniciTablosu",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AddForeignKey(
                name: "FK_KullaniciTablosu_DoktorTablosu_DoktorId",
                table: "KullaniciTablosu",
                column: "DoktorId",
                principalTable: "DoktorTablosu",
                principalColumn: "DoktorId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_KullaniciTablosu_DoktorTablosu_DoktorId",
                table: "KullaniciTablosu");

            migrationBuilder.AlterColumn<int>(
                name: "DoktorId",
                table: "KullaniciTablosu",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AddForeignKey(
                name: "FK_KullaniciTablosu_DoktorTablosu_DoktorId",
                table: "KullaniciTablosu",
                column: "DoktorId",
                principalTable: "DoktorTablosu",
                principalColumn: "DoktorId",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
