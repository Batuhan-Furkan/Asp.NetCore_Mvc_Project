﻿using HastaneRandevuSistemi.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.EntityFrameworkCore;

namespace HastaneRandevuSistemi.Controllers
{
    [Authorize(Roles = "Hasta")]
    public class RandevuController : Controller
    {
        private readonly MyContext _context;
        public RandevuController(MyContext context)
        {
            _context = context;
        }
    
        public IActionResult RandevuAl()
        {
            var bolumler = _context.BolumTablosu.ToList();

            return View(bolumler);
            
        }
       
        [HttpPost]
        public IActionResult DoktorlariGetir(int bolumId)
        {
            var doktorlar = _context.DoktorTablosu.Where(d => d.BolumId == bolumId).ToList();
            return Json(doktorlar);
        }
        [HttpPost]
        public IActionResult DoktorunRandevulariniGetir(int doktorId)
        {
            var doktor = _context.DoktorTablosu.FirstOrDefault(d => d.DoktorId == doktorId);

            if (doktor != null)
            {
                var randevular = doktor.RandevulariGetir();
                return Json(randevular);
            }

            return Json(null);
        }

    }
}
