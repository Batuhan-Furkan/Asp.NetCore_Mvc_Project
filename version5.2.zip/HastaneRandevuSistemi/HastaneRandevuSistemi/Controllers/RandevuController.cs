﻿using HastaneRandevuSistemi.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.EntityFrameworkCore;

namespace HastaneRandevuSistemi.Controllers
{
    [Authorize(Roles = "Hasta")]
    public class RandevuController : Controller
    {
        private readonly MyContext db;
        public IActionResult Index()
        {
            var bolumler = TumBolumleriGetir();
            return View();
        }
       
        public IActionResult RandevuAl()
        {
            var bolumler = TumBolumleriGetir();

            return View();
            
        }

        public List<BolumModel> TumBolumleriGetir()
        {
            return db.BolumTablosu.ToList();
            
        }
        public List<DoktorModel> DoktorlariGetir(int bolumId)
        {
            return db.DoktorTablosu.Where(d => d.BolumId == bolumId).ToList();
        }
        [HttpPost]
        public IActionResult DoktorGetir(int bolumId)
        {
            var doktorlar = DoktorlariGetir(bolumId);
            return Json(doktorlar);
        }
    }
}
