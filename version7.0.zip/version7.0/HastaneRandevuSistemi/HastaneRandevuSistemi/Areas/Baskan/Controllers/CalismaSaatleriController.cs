﻿using HastaneRandevuSistemi.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace HastaneRandevuSistemi.Areas.Baskan.Controllers
{
    [Authorize(Roles = "Baskan")]
    [Area("Baskan")]
    public class CalismaSaatleriController : Controller
    {
        //private readonly MyContext db2;
        private MyContext db = new MyContext();

       
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult CalismaZamaniBelirle()
        {
            ViewBag.Doktorlar = DoktorGetir();
            return View();
        }
        [HttpPost]
        public IActionResult CalismaZamaniBelirle(int selectedDoktorId, string DCSMBaslangicSaati, string DCSMBitisSaati, List<string> DCSMcalismaTarihi)
        {
            ViewBag.Doktorlar = DoktorGetir();
            if (ModelState.IsValid)
            {
                int saat = 0;
                int saat1 = 0;
                string[] baslangicsaatParcalari = DCSMBaslangicSaati.Split(':');
                string[] bitissaatParcalari = DCSMBitisSaati.Split(':');
                int.TryParse(baslangicsaatParcalari[0], out saat);
                int.TryParse(bitissaatParcalari[0], out saat1);
                if (saat1 > saat)
                {
                    for (int i = 0; i < DCSMcalismaTarihi.Count; i++)
                    {
                        var model = new DoktorCalismaSaatlariModeli
                        {
                            DoktorId = selectedDoktorId,
                            DCSMBaslangicSaati = DCSMBaslangicSaati,
                            DCSMBitisSaati = DCSMBitisSaati,
                            DCSMcalismaTarihi = DCSMcalismaTarihi[i]
                        };
                        db.doktorCalismaSaatlariModeliTablosu.Add(model);
                    }
                    db.SaveChanges();
                }
                else
                {
                    ViewBag.msg = "Başlangıç saati bitiş saatinden eşit ya da yüksek olamaz";
                }
                


                //if (db.doktorCalismaSaatlariModeliTablosu.Any(p => p.DCSMcalismaTarihi == yeni.DCSMcalismaTarihi))
                //{
                //    db.Update(yeni);
                //    db.SaveChanges();
                //    return RedirectToAction("Index");

                //}
                //else
                //{
                //    db.AddRange()
                //    db.Add(yeni);
                //    db.SaveChanges();
                //    return RedirectToAction("Index");
                //}

            }
            return View();
        }
        
        //public IActionResult CalismaZamaniBelirle(DoktorCalismaSaatlariModeli yeni, string s)
        //{
            
            
        //    if (ModelState.IsValid)
        //    {
        //        if (db.doktorCalismaSaatlariModeliTablosu.Any(p => p.DCSMcalismaTarihi == yeni.DCSMcalismaTarihi))
        //        {
        //            db.Update(yeni);
        //            db.SaveChanges();
        //            return RedirectToAction("Index");

        //        }
        //        else
        //        {
        //            db.Add(yeni);
        //            db.SaveChanges();
        //            return RedirectToAction("Index");
        //        }

        //    }

        //    return View();
        //}


        public List<DoktorModel> DoktorGetir()
        {
            List<DoktorModel> doktorListesi = db.DoktorTablosu.ToList();
            return doktorListesi;

        }
    }
}
