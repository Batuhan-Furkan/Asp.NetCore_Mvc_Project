﻿using HastaneRandevuSistemi.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Formats.Asn1;

namespace HastaneRandevuSistemi.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize(Roles ="Admin")]
    public class AdminController : Controller
    {
        private MyContext db = new MyContext();
        public IActionResult DoktorKayit()
        {
           
            return View();
        }
        public List<DoktorModel> DoktorGetir()
        {
            List<DoktorModel> doktorListesi = db.DoktorTablosu.ToList();
            return doktorListesi;

        }
        public IActionResult Doktor()
        {
            var doktorlar = db.DoktorTablosu.Include(d => d.bolum)
            .ToList();
            return View(doktorlar);
        }
        
        [HttpGet]       
        public IActionResult Edit(int id)
        {
            ViewBag.bolum = BolumGetir();
            var Model = db.DoktorTablosu.Find(id);
            if (Model == null)
            {
                return NotFound();
            }
            ViewBag.id=id;
            return View(Model);
        }
        
        [HttpPost]
        public IActionResult Edit(int id, DoktorModel Doktor)
        {
            ViewBag.bolum = BolumGetir();
                   Doktor.DoktorId=id;
            if(ModelState.IsValid) 
            { 
                db.Update(Doktor);
                db.SaveChanges();
                return View(Doktor);
            }
            else
            {
                return View(Doktor);
            }
                                 
            
            
        }
        public List<BolumModel> BolumGetir()
        {
            List<BolumModel> bolumListesi = db.BolumTablosu.ToList();
            return bolumListesi;

        }


    }

  
}
