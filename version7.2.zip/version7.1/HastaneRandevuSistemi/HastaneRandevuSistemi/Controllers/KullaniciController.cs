﻿using HastaneRandevuSistemi.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Metadata.Internal;

namespace HastaneRandevuSistemi.Controllers
{
    public class KullaniciController : Controller
    {
        private MyContext db = new MyContext();
        
        public IActionResult Index()
        {
            return View();
        }
        
        
        public IActionResult kullaniciEkle()
        {
            return View();
            
        }

        [HttpPost]
        public IActionResult kullaniciEkle(KullaniciModel y)
        {
            if (ModelState.IsValid)
            {
                if (db.KullaniciTablosu.Any(p=>p.KullaniciTcNo==y.KullaniciTcNo))//_kullaniciContext.KullaniciTablosu.Any(p => p.TcNo == y.TcNo))
                {
                    ViewBag.msg = "TcNo hatalı...";
                    return View(y);
                }
                else if(db.KullaniciTablosu.Any(p => p.KullaniciTcNo == y.KullaniciTcNo))//_kullaniciContext.KullaniciTablosu.Any(p => p.Mail == y.Mail))
                {
                    ViewBag.msg = "Mail hatalı...";
                    return View(y);
                }
                db.Add(y);
                db.SaveChanges();
                return RedirectToAction("kullaniciEkle");
            }
            else
            {
                ViewBag.msg = "EKLENEMEDİ...";
                return View(y);
            }
        }
    }
}
