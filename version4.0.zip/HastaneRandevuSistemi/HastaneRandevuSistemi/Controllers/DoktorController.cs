﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace HastaneRandevuSistemi.Controllers
{
    public class DoktorController : Controller
    {
        [Authorize(Roles = "Doktor")]
        public IActionResult Index()
        {
            return View();
        }
    }
}
