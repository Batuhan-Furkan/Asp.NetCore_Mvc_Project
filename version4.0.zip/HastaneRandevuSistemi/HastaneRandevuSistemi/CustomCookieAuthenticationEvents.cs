﻿internal class CustomCookieAuthenticationEvents
{
}