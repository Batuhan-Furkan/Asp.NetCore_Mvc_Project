﻿using HastaneRandevuSistemi.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.EntityFrameworkCore;
using System.Formats.Asn1;
using static Microsoft.AspNetCore.Mvc.ModelBinding.ModelStateDictionary;

namespace HastaneRandevuSistemi.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize(Roles ="Admin")]
    public class AdminController : Controller
    {
        private MyContext db = new MyContext();
        public IActionResult DoktorKayit()
        {
           
            return View();
        }
        public List<DoktorModel> DoktorGetir()
        {
            List<DoktorModel> doktorListesi = db.DoktorTablosu.ToList();
            return doktorListesi;

        }
        public IActionResult Doktor()
        {
            var doktorlar = db.DoktorTablosu.Include(d => d.bolum)
            .ToList();
            return View(doktorlar);
        }
        
        [HttpGet]       
        public IActionResult Edit(int id)
        {
            ViewBag.bolum = BolumGetir();
            var Model = db.DoktorTablosu.Find(id);
            if (Model == null)
            {
                return NotFound();
            }
            ViewBag.id=id;
            return View(Model);
        }
        
        [HttpPost]
        public IActionResult Edit(int id, DoktorModel Doktor)
        {
            ViewBag.bolum = BolumGetir();
            Doktor.DoktorId=id;
           

            if (ModelState.ErrorCount==4) 
            {
               var Mail =  mailgetir(id);
                if (Mail.Any(p => p.DoktorMail == Doktor.DoktorMail))
                {
                    ViewBag.msg = "Bu mail kullanılıyor.";
                    return View(Doktor);
                }
                else
                {

                    db.Update(Doktor);
                    db.SaveChanges();
                    return View(Doktor);
                }
            }
            else
            {
                return View(Doktor);
            }
        }

        public IActionResult Delete(int id)
        {
            var doktor = db.DoktorTablosu.Find(id);
            if (doktor == null)
            {
                return NotFound(); // Öğe bulunamazsa 404 Not Found döndür
            }
            return View(doktor);
        }
        [HttpPost, ActionName("Delete")]
        public IActionResult DeleteComplete(int id)
        {
            var doktor = db.DoktorTablosu.Find(id);
            if (doktor == null)
            {
                return NotFound(); // Öğe bulunamazsa 404 Not Found döndür
            }
            db.DoktorTablosu.Remove(doktor);
            db.SaveChanges();

            return RedirectToAction("Doktor");    
        }

        public IActionResult DoktorEkle()
        {
            ViewBag.BolumId = BolumGetir();
            return View();

        }
        [HttpPost]
        public IActionResult DoktorEkle(DoktorModel y)
        {
            ViewBag.BolumId = BolumGetir();
            if (ModelState.IsValid)
            {
                if (db.DoktorTablosu.Any(p => p.DoktorTcNo == y.DoktorTcNo))
                {
                    ViewBag.msg = "TcNo hatalı...";
                    return View(y);
                }
                else if (db.DoktorTablosu.Any(p => p.DoktorMail == y.DoktorMail))
                {
                    ViewBag.msg = "Mail hatalı...";
                    return View(y);
                }
                db.Add(y);
                db.SaveChanges();
                return RedirectToAction("Doktor");
            }
            else
            {
                ViewBag.msg = "EKLENEMEDİ...";
                return View(y);
            }
        }


        public List<BolumModel> BolumGetir()
        {
            List<BolumModel> bolumListesi = db.BolumTablosu.ToList();
            return bolumListesi;

        }

        public List<DoktorModel> mailgetir(int id)
        {
            List<DoktorModel> mailListesi = db.DoktorTablosu.AsNoTracking().ToList();
            DoktorModel doktorModel = mailListesi.Find(x=> x.DoktorId==id);
            if(doktorModel != null)
            {
                mailListesi.Remove(doktorModel);
            }


            return mailListesi;
        }
    }

  
}
