﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.CompilerServices;

namespace HastaneRandevuSistemi.Models
{
    public class KullaniciModel
    {
        [Key]
        public int KullaniciId { get; set; }


        [Required]
        [MaxLength(50)]
        public string KullaniciAd { get; set; }
        [Required]
        [MaxLength(50)]
        public string KullaniciSoyad { get; set; }
        [Required]
        [StringLength(11,MinimumLength =11)]
        
        public string KullaniciTcNo { get; set; }
        [Required]
        [Display(Name = "Dogum Tarihi")]
        [DisplayFormat(DataFormatString = "{0:dd-MMM-yyy}",ApplyFormatInEditMode =true)]
        public DateTime KullaniciDogumTarihi { get; set; }
        [Required]
        [StringLength(10, MinimumLength = 10)]
        [RegularExpression(@"^\d{10}$", ErrorMessage = "Telefon numarası 10 haneli olmalıdır.")]
        
        public string KullaniciTelefon { get; set; }
        [Required]
        [EmailAddress]
        public string KullaniciMail { get; set; }
        [Required]
        public bool KullaniciCinsiyet { get; set; }
        
        [Required]
        [DataType(DataType.Password)]
        public string KullaniciSifre { get; set; }

        [Required]
        [DataType(DataType.Password)]
        [Compare("KullaniciSifre")]
        [NotMapped]
        public string KullaniciSifreTekrar { get; set; }


        
        //public virtual DoktorModel Doktor { get; set; }
    }
}
