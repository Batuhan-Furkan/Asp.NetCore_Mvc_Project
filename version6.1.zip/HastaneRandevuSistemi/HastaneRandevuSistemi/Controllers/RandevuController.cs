﻿using HastaneRandevuSistemi.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.EntityFrameworkCore;
using System;

namespace HastaneRandevuSistemi.Controllers
{
    [Authorize(Roles ="Hasta")]
    public class RandevuController : Controller
    {

        private MyContext db = new MyContext();
       
        public IActionResult RandevuAl()
        {
            List<BolumModel> bolumListesi = db.BolumTablosu.ToList();
            return View(bolumListesi);
        }

        [HttpPost]
        public IActionResult Doktorlar(int selectedBolumId)
        {
            List<DoktorModel> doktorListesi = db.DoktorTablosu.Where(d => d.BolumId == selectedBolumId).ToList();
            return View(doktorListesi);
        }
        [HttpPost]
        public IActionResult RandevuTarihleri(int selectedDoktorId)
        {
            List<RandevuModel> randevuListesi = db.RandevuTablosu.Where(r => r.DoktorId == selectedDoktorId && r.Gun >= DateTime.Now).ToList();
            return View(randevuListesi);
        }
        [HttpPost]
        public IActionResult RandevuSaatleri(int selectedRandevuId)
        {
            RandevuModel secilenRandevu = db.RandevuTablosu.FirstOrDefault(r => r.Id == selectedRandevuId);

            if (secilenRandevu != null)
            {
                DateTime baslangicTarihi = secilenRandevu.Gun;
                DateTime bitisTarihi = secilenRandevu.Gun.AddHours(8);

                List<TimeSpan> erisilebilirSaatler = GetErisilebilirSaatler(secilenRandevu.DoktorId, secilenRandevu.Gun, baslangicTarihi, bitisTarihi, db);

                ViewBag.ErisilebilirSaatler = erisilebilirSaatler;

                return View();
            }

            return RedirectToAction("RandevuAl");
        }

        [HttpPost]
        public IActionResult RandevuKaydet(int selectedRandevuId, string selectedSaat)
        {
            RandevuModel secilenRandevu = db.RandevuTablosu.FirstOrDefault(r => r.Id == selectedRandevuId);

            if (secilenRandevu != null)
            {
                TimeSpan secilenSaat = TimeSpan.Parse(selectedSaat);

                RandevuModel yeniRandevu = new RandevuModel
                {
                    Gun = secilenRandevu.Gun.Date.Add(secilenSaat),
                    DoktorId = secilenRandevu.DoktorId
                };

                db.RandevuTablosu.Add(yeniRandevu);
                db.SaveChanges();

                ViewBag.RandevuKaydedildi = true;

                return View();
            }

            return RedirectToAction("RandevuAl");
        }

        private List<TimeSpan> GetErisilebilirSaatler(int doktorId, DateTime secilenTarih, DateTime baslangicTarihi, DateTime bitisTarihi, MyContext context)
        {
            List<DateTime> doktorRandevulari = context.RandevuTablosu
                .Where(r => r.DoktorId == doktorId && r.Gun.Date == secilenTarih.Date)
                .Select(r => r.Gun)
                .ToList();

            List<TimeSpan> erisilebilirSaatler = new List<TimeSpan>();

            TimeSpan currentSlot = baslangicTarihi.TimeOfDay;
            while (currentSlot <= bitisTarihi.TimeOfDay)
            {
                DateTime testDate = secilenTarih.Add(currentSlot);
                if (!doktorRandevulari.Any(t => t.TimeOfDay == currentSlot) && testDate > DateTime.Now)
                {
                    erisilebilirSaatler.Add(currentSlot);
                }

                currentSlot = currentSlot.Add(TimeSpan.FromMinutes(15));
            }

            return erisilebilirSaatler;
        }


    }

    
}
