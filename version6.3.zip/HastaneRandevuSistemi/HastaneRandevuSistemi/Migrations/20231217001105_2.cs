﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace HastaneRandevuSistemi.Migrations
{
    public partial class _2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_doktorCalismaSaatlariModeliTablosu_DoktorTablosu_DCSMDoktorDoktorId",
                table: "doktorCalismaSaatlariModeliTablosu");

            migrationBuilder.DropIndex(
                name: "IX_doktorCalismaSaatlariModeliTablosu_DCSMDoktorDoktorId",
                table: "doktorCalismaSaatlariModeliTablosu");

            migrationBuilder.DropColumn(
                name: "DCSMDoktorDoktorId",
                table: "doktorCalismaSaatlariModeliTablosu");

            migrationBuilder.AlterColumn<string>(
                name: "DCSMcalismaTarihi",
                table: "doktorCalismaSaatlariModeliTablosu",
                type: "nvarchar(max)",
                nullable: false,
                oldClrType: typeof(DateTime),
                oldType: "datetime2");

            migrationBuilder.AlterColumn<string>(
                name: "DCSMBitisSaati",
                table: "doktorCalismaSaatlariModeliTablosu",
                type: "nvarchar(max)",
                nullable: false,
                oldClrType: typeof(TimeSpan),
                oldType: "time");

            migrationBuilder.AlterColumn<string>(
                name: "DCSMBaslangicSaati",
                table: "doktorCalismaSaatlariModeliTablosu",
                type: "nvarchar(max)",
                nullable: false,
                oldClrType: typeof(TimeSpan),
                oldType: "time");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<DateTime>(
                name: "DCSMcalismaTarihi",
                table: "doktorCalismaSaatlariModeliTablosu",
                type: "datetime2",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AlterColumn<TimeSpan>(
                name: "DCSMBitisSaati",
                table: "doktorCalismaSaatlariModeliTablosu",
                type: "time",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AlterColumn<TimeSpan>(
                name: "DCSMBaslangicSaati",
                table: "doktorCalismaSaatlariModeliTablosu",
                type: "time",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AddColumn<int>(
                name: "DCSMDoktorDoktorId",
                table: "doktorCalismaSaatlariModeliTablosu",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_doktorCalismaSaatlariModeliTablosu_DCSMDoktorDoktorId",
                table: "doktorCalismaSaatlariModeliTablosu",
                column: "DCSMDoktorDoktorId");

            migrationBuilder.AddForeignKey(
                name: "FK_doktorCalismaSaatlariModeliTablosu_DoktorTablosu_DCSMDoktorDoktorId",
                table: "doktorCalismaSaatlariModeliTablosu",
                column: "DCSMDoktorDoktorId",
                principalTable: "DoktorTablosu",
                principalColumn: "DoktorId",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
