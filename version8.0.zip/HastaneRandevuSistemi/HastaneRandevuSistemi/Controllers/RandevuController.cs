﻿using HastaneRandevuSistemi.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.EntityFrameworkCore;
using System;
using System.Security.Claims;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace HastaneRandevuSistemi.Controllers
{
    [Authorize(Roles = "Hasta")]
    public class RandevuController : Controller
    {
        

        private MyContext db = new MyContext();

       
        public IActionResult RandevuAl()
        {
            var authList = User.Claims.ToList();
            var mail = authList[0].Value;
          
         
            ViewBag.Sehirler = SehirGetir();
            ViewBag.ilceler = IlceGetir();

            //RandevuModel model = new RandevuModel();


            return View();
        }
        [ValidateAntiForgeryToken]
        [HttpPost]
        public IActionResult RandevuAl(RandevuModel model)
        {
            ViewBag.Sehirler = SehirGetir();
            ViewBag.ilceler = IlceGetir();

            //List<KullaniciModel> kullaniciListesi = kullaniciGetir();

            //var ilce = IlceGetir(selectedCity);

            //return Json(new { ilce });

            //var authList = User.Claims.ToList();
            //var hastaMail = authList[0].Value;

            //var hasta = (from p in kullaniciListesi
            //             where p.KullaniciMail == hastaMail
            //             select p).FirstOrDefault();

            //model.HastaTcNo = hasta.KullaniciTcNo;
            //model.HastaAdi = hasta.KullaniciAd;
            //model.HastaSoyadi = hasta.KullaniciSoyad;


            return View();

        }






        public JsonResult GetSehir()
        {
            var sehir = db.SehirTablosu.OrderBy(p => p.SehirAdi).ToList();
            return new JsonResult(sehir);
        }

        public JsonResult Getilce(int id)
        {
            var ilce = db.IlceTablosu.Where(p=>p.Sehirid == id).OrderBy(p => p.IlceAdi).ToList();
            return new JsonResult(ilce);

        }

        public JsonResult GetHastane(int id)
        {
            var hastaneler = db.HastaneTablosu.Where(p => p.ilceid == id).OrderBy(p => p.HastaneAdi).ToList();
            return new JsonResult(hastaneler);
        }


        public JsonResult GetBolum()
        {
            var bolumler = db.BolumTablosu.OrderBy(p=>p.BolumAdi).ToList();
            return new JsonResult(bolumler);
        }

        //public JsonResult GetDoktor(int bolumid, int hastaneid)
        //{
        //    var doktorlar = db.DoktorTablosu.Where(p=>p.BolumId == bolumid && p.).OrderBy()
        //}




















        public List<KullaniciModel> kullaniciGetir()
        {
            List<KullaniciModel> kullaniciListesi = db.KullaniciTablosu.ToList();
            return kullaniciListesi;

        }
        public List<HastanelerModel> hastaneGetir()
        {
            List<HastanelerModel> hastaneListesi = db.HastaneTablosu.ToList();
            return hastaneListesi;

        }
        public List<IlceModel> IlceGetir() 
        {
            List<IlceModel> ilceListesi = db.IlceTablosu.ToList();

            //  List<string> ilceListesi = db.IlceTablosu.Where(p=>p.Sehirid==sehirid).Select(p=>p.IlceAdi).ToList(); //parametre:şehir id  return type list<string>

            return ilceListesi;

        }
        public List<string> IlceGetir(int sehirid)
        {
            List<string> ilceListesi = db.IlceTablosu.Where(p=>p.Sehirid==sehirid).Select(p=>p.IlceAdi).ToList(); //parametre:şehir id  return type list<string>
            return ilceListesi;
        }
        public List<SehirModel> SehirGetir()
        {
            List<SehirModel> sehirListesi = db.SehirTablosu.ToList();
            return sehirListesi;

        }
        public List<DoktorModel> DoktorGetir()
        {
            List<DoktorModel> doktorListesi = db.DoktorTablosu.ToList();
            return doktorListesi;

        }


    }
}
