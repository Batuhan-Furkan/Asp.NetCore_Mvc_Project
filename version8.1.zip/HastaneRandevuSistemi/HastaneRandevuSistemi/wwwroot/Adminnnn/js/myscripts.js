$(document).ready(function () {
    $('#selectedsehir').attr('disabled', true);
    $('#selectedilce').attr('disabled', true);
    $('#selectedhastane').attr('disabled', true);
    $('#selectedbolum').attr('disabled', true);
    $('#selecteddoktor').attr('disabled', true);
    LoadSehirler();
    var hastaneidsi;
    $('#selectedsehir').change(function () {
        var ilceidsi = $(this).val();
        console.log(ilceidsi);
        if (ilceidsi > 0) {
            Loadilceler(ilceidsi);
        }
        else {
            alert("Sehir secin!");
            $('#selectedilce').empty();
            $('#selectedhastane').empty();
            $('#selectedbolum').empty();
            $('#selecteddoktor').empty();
            $('#selectedilce').attr('disabled', true);
            $('#selectedhastane').attr('disabled', true);
            $('#selectedbolum').attr('disabled', true);
            $('#selecteddoktor').attr('disabled', true);
            $('#selectedilce').append('<option>--�lce secin--</option>');
            $('#selectedhastane').append('<option>--Hastane secin--</option>');
            $('#selectedbolum').append('<option>--Bolum secin--</option>');
            $('#selecteddoktor').append('<option>--Doktor secin--</option>');
        }
    });

    $('#selectedilce').change(function () {
        var sehiridsi = $(this).val();
        if (sehiridsi > 0) {
            Loadhastaneler(sehiridsi);
        }
        else {
            alert("Hastane secin!");
            $('#selectedhastane').empty();
            $('#selectedbolum').empty();
            $('#selecteddoktor').empty();
            $('#selectedhastane').attr('disabled', true);
            $('#selectedbolum').attr('disabled', true);
            $('#selecteddoktor').attr('disabled', true);
            $('#selectedhastane').append('<option>--Hastane secin--</option>');
            $('#selectedbolum').append('<option>--Bolum secin--</option>');
            $('#selecteddoktor').append('<option>--Doktor secin--</option>');
        }
    });

    $('#selectedhastane').change(function () {   
        hastaneidsi = $(this).val();
        console.log(hastaneidsi);
        Loadbolumler();
        
    });


    $('#selectedbolum').change(function () {
        var bolumidsi = $(this).val();
        hastaneidsi = $(this).val();
        if (bolumidsi > 0 && hastaneidsi > 0) {
            Loaddoktorlar(bolumidsi, hastaneidsi);
        }
        else {
            alert("Hastane secin!");
            $('#selectedhastane').empty();
            $('#selectedbolum').empty();
            $('#selecteddoktor').empty();
            $('#selectedhastane').attr('disabled', true);
            $('#selectedbolum').attr('disabled', true);
            $('#selecteddoktor').attr('disabled', true);
            $('#selectedhastane').append('<option>--Hastane secin--</option>');
            $('#selectedbolum').append('<option>--Bolum secin--</option>');
            $('#selecteddoktor').append('<option>--Doktor secin--</option>');
        }
    });




});


function LoadSehirler() {
    $('#selectedsehir').empty();

    $.ajax({
        url: '/Randevu/GetSehir',
        success: function (response) {
            if (response != null && response != undefined && response.length > 0) {
                $('#selectedsehir').attr('disabled', false);
                $('#selectedsehir').append('<option>--Sehir secin--</option>');
                $('#selectedilce').append('<option>--�lce secin--</option>');
                $('#selectedhastane').append('<option>--Hastane secin--</option>');
                $('#selectedbolum').append('<option>--Bolum secin--</option>');
                $('#selecteddoktor').append('<option>--Doktor secin--</option>');
                $.each(response, function (i, data) {
                    $('#selectedsehir').append('<option value=' + data.sehirId + '>' + data.sehirAdi + '</option>');
                    console.log(i.SehirId, i.SehirAdi,i,data);
                });
            }
            else {
                $('#selectedsehir').attr('disabled', true);
                $('#selectedilce').attr('disabled', true);
                $('#selectedhastane').attr('disabled', true);
                $('#selectedbolum').attr('disabled', true);
                $('#selecteddoktor').attr('disabled', true);
                $('#selectedsehir').append('<option>--�ehir yok--</option>');
                $('#selectedilce').append('<option>--�l�e yok--</option>');
                $('#selectedhastane').append('<option>--Hastane yok--</option>');
                $('#selectedbolum').append('<option>--Bolum yok--</option>');
                $('#selecteddoktor').append('<option>--Doktor secin--</option>');
            }
        },
        error: function (error) {
            alert(error);
        }

    });
}

function Loadilceler(ilceidsi) {
    $('#selectedilce').empty();
    $('#selectedhastane').empty();
    $('#selectedbolum').empty();
    $('#selecteddoktor').empty();
    $('#selectedhastane').attr('disabled', true);
    $('#selectedbolum').attr('disabled', true);
    $('#selecteddoktor').attr('disabled', true);

    $.ajax({
        url: '/Randevu/Getilce?id=' + ilceidsi,
        success: function (response) {
            if (response != null && response != undefined && response.length > 0) {
                $('#selectedilce').attr('disabled', false);
                $('#selectedilce').append('<option>--�lce secin--</option>');
                $('#selectedhastane').append('<option>--Hastane secin--</option>');
                $('#selectedbolum').append('<option>--Bolum secin--</option>');
                $('#selecteddoktor').append('<option>--Doktor secin--</option>');
                $.each(response, function (i, data) {
                    $('#selectedilce').append('<option value=' + data.ilceid + '>' + data.ilceAdi + '</option>');
                    console.log(i, data);
                });
            }
            else {
                $('#selectedilce').attr('disabled', true);
                $('#selectedhastane').attr('disabled', true);
                $('#selectedbolum').attr('disabled', true);
                $('#selecteddoktor').attr('disabled', true);
                $('#selectedilce').append('<option>--�l�e yok--</option>');
                $('#selectedhastane').append('<option>--Hastane yok--</option>');
                $('#selectedbolum').append('<option>--Bolum yok--</option>');
                $('#selecteddoktor').append('<option>--Doktor yok--</option>');
            }
        },
        error: function (error) {
            alert(error);
        }

    });
}


function Loadhastaneler(sehiridsi) {
    $('#selectedhastane').empty();
    $('#selectedbolum').empty();
    $('#selecteddoktor').empty();
    $('#selectedbolum').attr('disabled', true);
    $('#selecteddoktor').attr('disabled', true);

    $.ajax({
        url: '/Randevu/GetHastane?id=' + sehiridsi,
        success: function (response) {
            if (response != null && response != undefined && response.length > 0) {
                $('#selectedhastane').attr('disabled', false);
                $('#selectedhastane').append('<option>--Hastane secin--</option>');
                $('#selectedbolum').append('<option>--Bolum secin--</option>');
                $('#selecteddoktor').append('<option>--Doktor yok--</option>');
                $.each(response, function (i, data) {
                    $('#selectedhastane').append('<option value=' + data.hastaneId + '>' + data.hastaneAdi + '</option>');
                    console.log(i, data);
                });
            }
            else {
                $('#selectedhastane').attr('disabled', true);
                $('#selectedbolum').attr('disabled', true);
                $('#selecteddoktor').attr('disabled', true);
                $('#selectedhastane').append('<option>--Hastane yok--</option>');
                $('#selectedbolum').append('<option>--Bolum yok--</option>');
                $('#selecteddoktor').append('<option>--Doktor yok--</option>');
            }
        },
        error: function (error) {
            alert(error);
        }

    });
}


function Loadbolumler() {
    $('#selectedbolum').empty();
    $('#selecteddoktor').empty();
    $('#selecteddoktor').attr('disabled', true);
    $.ajax({
        url: '/Randevu/GetBolum' ,
        success: function (response) {
            if (response != null && response != undefined && response.length > 0) {
                $('#selectedbolum').attr('disabled', false);
                $('#selectedbolum').append('<option>--Bolum secin--</option>');
                $('#selecteddoktor').append('<option>--Doktor yok--</option>');
                $.each(response, function (i, data) {
                    $('#selectedbolum').append('<option value=' + data.bolumId + '>' + data.bolumAdi + '</option>');
                    console.log(i, data);
                });
            }
            else {
                $('#selectedbolum').attr('disabled', true);
                $('#selecteddoktor').attr('disabled', true);
                $('#selectedbolum').append('<option>--Bolum yok--</option>');
                $('#selecteddoktor').append('<option>--Doktor yok--</option>');
            }
        },
        error: function (error) {
            alert(error);
        }

    });
}


function Loaddoktorlar(bolumidsi,hastaneidsi) {
    $('#selecteddoktor').empty();
    $.ajax({
        url: '/Randevu/GetDoktor?bolumid=' + bolumidsi + '&&hastaneid=' + hastaneidsi,
        success: function (response) {
            if (response != null && response != undefined && response.length > 0) {
                $('#selecteddoktor').attr('disabled', false);
                $('#selecteddoktor').append('<option>--Doktor yok--</option>');
                $.each(response, function (i, data) {
                    $('#selecteddoktor').append('<option value=' + data.doktorId + '>' + data.doktorAdi + '</option>');
                    console.log(i, data);
                });
            }
            else {
                $('#selecteddoktor').attr('disabled', true);
                $('#selecteddoktor').append('<option>--Doktor yok--</option>');
     
            }
        },
        error: function (error) {
            alert(error);
        }

    });
}
