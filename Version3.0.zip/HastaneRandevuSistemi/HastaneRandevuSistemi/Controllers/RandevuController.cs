﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace HastaneRandevuSistemi.Controllers
{
    public class RandevuController : Controller
    {
        [Authorize]
        public IActionResult Index()
        {
            return View();
        }
    }
}
