﻿using HastaneRandevuSistemi.Models;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using Microsoft.Net.Http.Headers;
using Microsoft.AspNetCore.Authentication;
using System.Linq;


namespace HastaneRandevuSistemi.Controllers
{
    public class LoginController : Controller
    {
        MyContext db = new MyContext();
        public IActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public IActionResult GirisYap() 
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> GirisYap(string sifre, string tcno)
        {

            var birlesiktablo = db.DoktorTablosu.Select(doktor => new { TcNo = doktor.DoktorTcNo, Sifre = doktor.DoktorSifre })
                .Union(db.KullaniciTablosu.Select(kullanici => new { TcNo = kullanici.KullaniciTcNo, Sifre = kullanici.KullaniciSifre }));
            var tabloIcerik = birlesiktablo.FirstOrDefault(p=> p.TcNo == tcno && p.Sifre == sifre);
            if (tabloIcerik != null)
            {
                var claims = new List<Claim>
                  {
                      new Claim(ClaimTypes.Name, tcno)
                  };
                var useridentity = new ClaimsIdentity(claims, "Login");
                ClaimsPrincipal principal = new ClaimsPrincipal(useridentity);
                await HttpContext.SignInAsync(principal);
                return RedirectToAction("Index", "Randevu");
            }
        
            return View();
        }
    }
}
