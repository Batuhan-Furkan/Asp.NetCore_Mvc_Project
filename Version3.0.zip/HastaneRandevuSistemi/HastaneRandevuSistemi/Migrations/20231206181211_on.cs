﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace HastaneRandevuSistemi.Migrations
{
    public partial class on : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "DoktorId",
                table: "KullaniciTablosu",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateTable(
                name: "DoktorTablosu",
                columns: table => new
                {
                    DoktorId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DoktorAdi = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    DoktorSoyad = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    DoktorTcNo = table.Column<string>(type: "nvarchar(11)", maxLength: 11, nullable: false),
                    DoktorTelefon = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: false),
                    DoktorMail = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DoktorSifre = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DoktorTablosu", x => x.DoktorId);
                });

            migrationBuilder.CreateIndex(
                name: "IX_KullaniciTablosu_DoktorId",
                table: "KullaniciTablosu",
                column: "DoktorId");

            migrationBuilder.AddForeignKey(
                name: "FK_KullaniciTablosu_DoktorTablosu_DoktorId",
                table: "KullaniciTablosu",
                column: "DoktorId",
                principalTable: "DoktorTablosu",
                principalColumn: "DoktorId",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_KullaniciTablosu_DoktorTablosu_DoktorId",
                table: "KullaniciTablosu");

            migrationBuilder.DropTable(
                name: "DoktorTablosu");

            migrationBuilder.DropIndex(
                name: "IX_KullaniciTablosu_DoktorId",
                table: "KullaniciTablosu");

            migrationBuilder.DropColumn(
                name: "DoktorId",
                table: "KullaniciTablosu");
        }
    }
}
