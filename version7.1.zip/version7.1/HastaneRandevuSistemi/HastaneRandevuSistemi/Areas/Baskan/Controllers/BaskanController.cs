﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace HastaneRandevuSistemi.Areas.Baskan.Controllers
{
    [Authorize(Roles = "Hasta")]

    public class BaskanController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
