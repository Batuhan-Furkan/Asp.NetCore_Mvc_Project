﻿using HastaneRandevuSistemi.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Formats.Asn1;

namespace HastaneRandevuSistemi.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize(Roles ="Admin")]
    public class AdminController : Controller
    {
        private MyContext db = new MyContext();
        public IActionResult DoktorKayit()
        {
           
            return View();
        }
        public List<DoktorModel> DoktorGetir()
        {
            List<DoktorModel> doktorListesi = db.DoktorTablosu.ToList();
            return doktorListesi;

        }
        public IActionResult Doktor()
        {
            var doktorlar = db.DoktorTablosu.Include(d => d.bolum)
            .ToList();
            return View(doktorlar);
        }

    


    }

  
}
