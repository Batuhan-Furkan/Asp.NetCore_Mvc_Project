﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace HastaneRandevuSistemi.Migrations
{
    public partial class _1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "BolumTablosu",
                columns: table => new
                {
                    BolumId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    BolumAdi = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BolumTablosu", x => x.BolumId);
                });

            migrationBuilder.CreateTable(
                name: "KullaniciTablosu",
                columns: table => new
                {
                    KullaniciId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    state = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    KullaniciAd = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    KullaniciSoyad = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    KullaniciTcNo = table.Column<string>(type: "nvarchar(11)", maxLength: 11, nullable: false),
                    KullaniciDogumTarihi = table.Column<DateTime>(type: "datetime2", nullable: false),
                    KullaniciTelefon = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: false),
                    KullaniciMail = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    KullaniciCinsiyet = table.Column<bool>(type: "bit", nullable: false),
                    KullaniciSifre = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_KullaniciTablosu", x => x.KullaniciId);
                });

            migrationBuilder.CreateTable(
                name: "DoktorTablosu",
                columns: table => new
                {
                    DoktorId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    state = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    BolumId = table.Column<int>(type: "int", nullable: false),
                    DoktorAdi = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    DoktorSoyad = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    DoktorTcNo = table.Column<string>(type: "nvarchar(11)", maxLength: 11, nullable: false),
                    DoktorTelefon = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: false),
                    DoktorMail = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DoktorSifre = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DoktorTablosu", x => x.DoktorId);
                    table.ForeignKey(
                        name: "FK_DoktorTablosu_BolumTablosu_BolumId",
                        column: x => x.BolumId,
                        principalTable: "BolumTablosu",
                        principalColumn: "BolumId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "RandevuTablosu",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DoktorId = table.Column<int>(type: "int", nullable: false),
                    Musait = table.Column<bool>(type: "bit", nullable: false),
                    Gun = table.Column<DateTime>(type: "datetime2", nullable: false),
                    DoktorModelDoktorId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RandevuTablosu", x => x.Id);
                    table.ForeignKey(
                        name: "FK_RandevuTablosu_DoktorTablosu_DoktorModelDoktorId",
                        column: x => x.DoktorModelDoktorId,
                        principalTable: "DoktorTablosu",
                        principalColumn: "DoktorId");
                });

            migrationBuilder.CreateIndex(
                name: "IX_DoktorTablosu_BolumId",
                table: "DoktorTablosu",
                column: "BolumId");

            migrationBuilder.CreateIndex(
                name: "IX_RandevuTablosu_DoktorModelDoktorId",
                table: "RandevuTablosu",
                column: "DoktorModelDoktorId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "KullaniciTablosu");

            migrationBuilder.DropTable(
                name: "RandevuTablosu");

            migrationBuilder.DropTable(
                name: "DoktorTablosu");

            migrationBuilder.DropTable(
                name: "BolumTablosu");
        }
    }
}
