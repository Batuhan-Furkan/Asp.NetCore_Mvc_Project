﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace HastaneRandevuSistemi.Migrations
{
    public partial class _2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "doktorCalismaSaatlariModeliTablosu",
                columns: table => new
                {
                    DCSMId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DoktorId = table.Column<int>(type: "int", nullable: false),
                    DCSMDoktorDoktorId = table.Column<int>(type: "int", nullable: false),
                    DCSMBaslangicSaati = table.Column<TimeSpan>(type: "time", nullable: false),
                    DCSMBitisSaati = table.Column<TimeSpan>(type: "time", nullable: false),
                    DCSMcalismaTarihi = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_doktorCalismaSaatlariModeliTablosu", x => x.DCSMId);
                    table.ForeignKey(
                        name: "FK_doktorCalismaSaatlariModeliTablosu_DoktorTablosu_DCSMDoktorDoktorId",
                        column: x => x.DCSMDoktorDoktorId,
                        principalTable: "DoktorTablosu",
                        principalColumn: "DoktorId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_doktorCalismaSaatlariModeliTablosu_DCSMDoktorDoktorId",
                table: "doktorCalismaSaatlariModeliTablosu",
                column: "DCSMDoktorDoktorId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "doktorCalismaSaatlariModeliTablosu");
        }
    }
}
