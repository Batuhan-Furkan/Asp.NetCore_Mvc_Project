﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace HastaneRandevuSistemi.Migrations
{
    public partial class dokuz : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_KullaniciTablosu_Mail",
                table: "KullaniciTablosu");

            migrationBuilder.DropIndex(
                name: "IX_KullaniciTablosu_TcNo",
                table: "KullaniciTablosu");

            migrationBuilder.DropColumn(
                name: "Mail",
                table: "KullaniciTablosu");

            migrationBuilder.RenameColumn(
                name: "Telefon",
                table: "KullaniciTablosu",
                newName: "KullaniciTelefon");

            migrationBuilder.RenameColumn(
                name: "TcNo",
                table: "KullaniciTablosu",
                newName: "KullaniciTcNo");

            migrationBuilder.RenameColumn(
                name: "Soyad",
                table: "KullaniciTablosu",
                newName: "KullaniciSoyad");

            migrationBuilder.RenameColumn(
                name: "Sifre",
                table: "KullaniciTablosu",
                newName: "KullaniciSifre");

            migrationBuilder.RenameColumn(
                name: "DogumTarihi",
                table: "KullaniciTablosu",
                newName: "KullaniciDogumTarihi");

            migrationBuilder.RenameColumn(
                name: "Cinsiyet",
                table: "KullaniciTablosu",
                newName: "KullaniciCinsiyet");

            migrationBuilder.RenameColumn(
                name: "Ad",
                table: "KullaniciTablosu",
                newName: "KullaniciAd");

            migrationBuilder.AddColumn<string>(
                name: "KullaniciMail",
                table: "KullaniciTablosu",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "KullaniciMail",
                table: "KullaniciTablosu");

            migrationBuilder.RenameColumn(
                name: "KullaniciTelefon",
                table: "KullaniciTablosu",
                newName: "Telefon");

            migrationBuilder.RenameColumn(
                name: "KullaniciTcNo",
                table: "KullaniciTablosu",
                newName: "TcNo");

            migrationBuilder.RenameColumn(
                name: "KullaniciSoyad",
                table: "KullaniciTablosu",
                newName: "Soyad");

            migrationBuilder.RenameColumn(
                name: "KullaniciSifre",
                table: "KullaniciTablosu",
                newName: "Sifre");

            migrationBuilder.RenameColumn(
                name: "KullaniciDogumTarihi",
                table: "KullaniciTablosu",
                newName: "DogumTarihi");

            migrationBuilder.RenameColumn(
                name: "KullaniciCinsiyet",
                table: "KullaniciTablosu",
                newName: "Cinsiyet");

            migrationBuilder.RenameColumn(
                name: "KullaniciAd",
                table: "KullaniciTablosu",
                newName: "Ad");

            migrationBuilder.AddColumn<string>(
                name: "Mail",
                table: "KullaniciTablosu",
                type: "nvarchar(450)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.CreateIndex(
                name: "IX_KullaniciTablosu_Mail",
                table: "KullaniciTablosu",
                column: "Mail",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_KullaniciTablosu_TcNo",
                table: "KullaniciTablosu",
                column: "TcNo",
                unique: true);
        }
    }
}
