﻿using HastaneRandevuSistemi.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace HastaneRandevuSistemi.Areas.Baskan.Controllers
{
    [Authorize(Roles = "Baskan")]
    [Area("Baskan")]
    public class CalismaSaatleriController : Controller
    {
        //private readonly MyContext db2;
        private MyContext db = new MyContext();

       
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult CalismaZamaniBelirle()
        {
            ViewBag.Doktorlar = DoktorGetir();
            return View();
        }
        [HttpPost]
        public IActionResult CalismaZamaniBelirle(DoktorCalismaSaatlariModeli yeni)
        {
            ViewBag.Doktorlar = DoktorGetir();
            if (ModelState.IsValid)
            {
                if (db.doktorCalismaSaatlariModeliTablosu.Any(p => p.DCSMcalismaTarihi == yeni.DCSMcalismaTarihi))
                {
                    db.Update(yeni);
                    db.SaveChanges();
                    return RedirectToAction("Index");

                }
                else
                {
                    db.Add(yeni);
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }

            }
            return View();
        }
        
        //public IActionResult CalismaZamaniBelirle(DoktorCalismaSaatlariModeli yeni, string s)
        //{
            
            
        //    if (ModelState.IsValid)
        //    {
        //        if (db.doktorCalismaSaatlariModeliTablosu.Any(p => p.DCSMcalismaTarihi == yeni.DCSMcalismaTarihi))
        //        {
        //            db.Update(yeni);
        //            db.SaveChanges();
        //            return RedirectToAction("Index");

        //        }
        //        else
        //        {
        //            db.Add(yeni);
        //            db.SaveChanges();
        //            return RedirectToAction("Index");
        //        }

        //    }

        //    return View();
        //}


        public List<DoktorModel> DoktorGetir()
        {
            List<DoktorModel> doktorListesi = db.DoktorTablosu.ToList();
            return doktorListesi;

        }
    }
}
