﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace HastaneRandevuSistemi.Controllers
{
    public class RandevuController : Controller
    {
        [Authorize(Roles ="Hasta")]
        public IActionResult Index()
        {
            
            
            return View();
        }
    }
}
