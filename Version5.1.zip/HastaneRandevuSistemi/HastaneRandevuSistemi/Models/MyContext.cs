﻿using Microsoft.EntityFrameworkCore;

namespace HastaneRandevuSistemi.Models
{
    public class MyContext : DbContext
    {
        public DbSet<KullaniciModel> KullaniciTablosu { get; set; }
        public DbSet<DoktorModel>  DoktorTablosu { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Server=(localdb)\mssqllocaldb; Database=HastaneDB; Trusted_Connection=True;");
        }
        
    }
}
