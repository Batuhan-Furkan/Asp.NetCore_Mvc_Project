﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace HastaneRandevuSistemi.Migrations
{
    public partial class _24 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "bolum",
                table: "DoktorTablosu");

            migrationBuilder.AddColumn<int>(
                name: "BolumId",
                table: "DoktorTablosu",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateTable(
                name: "BolumTablosu",
                columns: table => new
                {
                    BolumId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    BolumAdi = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BolumTablosu", x => x.BolumId);
                });

            migrationBuilder.CreateIndex(
                name: "IX_DoktorTablosu_BolumId",
                table: "DoktorTablosu",
                column: "BolumId");

            migrationBuilder.AddForeignKey(
                name: "FK_DoktorTablosu_BolumTablosu_BolumId",
                table: "DoktorTablosu",
                column: "BolumId",
                principalTable: "BolumTablosu",
                principalColumn: "BolumId",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_DoktorTablosu_BolumTablosu_BolumId",
                table: "DoktorTablosu");

            migrationBuilder.DropTable(
                name: "BolumTablosu");

            migrationBuilder.DropIndex(
                name: "IX_DoktorTablosu_BolumId",
                table: "DoktorTablosu");

            migrationBuilder.DropColumn(
                name: "BolumId",
                table: "DoktorTablosu");

            migrationBuilder.AddColumn<string>(
                name: "bolum",
                table: "DoktorTablosu",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: false,
                defaultValue: "");
        }
    }
}
