﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace HastaneRandevuSistemi.Migrations
{
    public partial class onbes : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_KullaniciTablosu_DoktorTablosu_DoktorId",
                table: "KullaniciTablosu");

            migrationBuilder.DropIndex(
                name: "IX_KullaniciTablosu_DoktorId",
                table: "KullaniciTablosu");

            migrationBuilder.DropColumn(
                name: "DoktorId",
                table: "KullaniciTablosu");

            migrationBuilder.AddColumn<int>(
                name: "DoktorModelDoktorId",
                table: "KullaniciTablosu",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_KullaniciTablosu_DoktorModelDoktorId",
                table: "KullaniciTablosu",
                column: "DoktorModelDoktorId");

            migrationBuilder.AddForeignKey(
                name: "FK_KullaniciTablosu_DoktorTablosu_DoktorModelDoktorId",
                table: "KullaniciTablosu",
                column: "DoktorModelDoktorId",
                principalTable: "DoktorTablosu",
                principalColumn: "DoktorId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_KullaniciTablosu_DoktorTablosu_DoktorModelDoktorId",
                table: "KullaniciTablosu");

            migrationBuilder.DropIndex(
                name: "IX_KullaniciTablosu_DoktorModelDoktorId",
                table: "KullaniciTablosu");

            migrationBuilder.DropColumn(
                name: "DoktorModelDoktorId",
                table: "KullaniciTablosu");

            migrationBuilder.AddColumn<int>(
                name: "DoktorId",
                table: "KullaniciTablosu",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_KullaniciTablosu_DoktorId",
                table: "KullaniciTablosu",
                column: "DoktorId");

            migrationBuilder.AddForeignKey(
                name: "FK_KullaniciTablosu_DoktorTablosu_DoktorId",
                table: "KullaniciTablosu",
                column: "DoktorId",
                principalTable: "DoktorTablosu",
                principalColumn: "DoktorId",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
