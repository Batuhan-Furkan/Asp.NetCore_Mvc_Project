﻿using HastaneRandevuSistemi.Models;
using System;

namespace HastaneRandevuSistemi.Services
{
    public class RandevuServices
    {
        private readonly MyContext db;

        public RandevuServices(MyContext dbContext)
        {
            db = dbContext;
        }

        public List<TimeSpan> GetMusaitsForDate(DateTime tarih)
        {
            var randevular = db.RandevuTablosu
                .Where(r => r.Gun == tarih)
                .ToList();

            var musaitSaatler = Enumerable.Range(9, 9) // 9:00'dan başlayarak 6:00'a kadar
                .SelectMany(saat => new List<TimeSpan>
                {
                TimeSpan.FromHours(saat),
                TimeSpan.FromHours(saat).Add(TimeSpan.FromMinutes(15)),
                TimeSpan.FromHours(saat).Add(TimeSpan.FromMinutes(30)),
                TimeSpan.FromHours(saat).Add(TimeSpan.FromMinutes(45))
                })
                .ToList();

            foreach (var randevu in randevular)
            {
                musaitSaatler.Remove(randevu.Saat);
            }

            return musaitSaatler;
        }

        public void RandevuAl(DateTime tarih, TimeSpan saat)
        {
            var randevu = new RandevuModel
            {
                Gun = tarih,
                Saat = saat,
                Musait = false
            };

            db.RandevuTablosu.Add(randevu);
            db.SaveChanges();
        }
    }
}
