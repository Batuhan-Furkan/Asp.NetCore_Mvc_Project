﻿using HastaneRandevuSistemi.Models;
using HastaneRandevuSistemi.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace HastaneRandevuSistemi.Controllers
{
    [Authorize(Roles ="Hasta")]

    public class RandevuController : Controller
    {
        private readonly RandevuServices _randevuService;
        public RandevuController(RandevuServices randevuService)
        {
            _randevuService = randevuService;
        }
        public IActionResult RandevuAl()
        {
            // Bugünden itibaren müsait saatleri al
            var bugun = DateTime.Today;
            var musaitSaatler = _randevuService.GetMusaitsForDate(bugun);

            ViewBag.MusaitSaatler = musaitSaatler;

            return View();
        }
        [HttpPost]
        public IActionResult RandevuAl(DateTime tarih, TimeSpan saat)
        {
            // Randevu al
            _randevuService.RandevuAl(tarih, saat);

            // İstenirse başka bir işlem yapılabilir (örneğin, onay sayfasına yönlendirme)

            return RedirectToAction("Index", "Home");
        }
    }

    
}
